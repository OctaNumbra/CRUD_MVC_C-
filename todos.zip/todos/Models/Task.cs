﻿using MySqlConnector;

namespace todos.Models
{
    public class Task
    {

        private static string db_config = "" + "server=127.0.0.1;" +
            "Port=3306;" +
            "Database=todos;" +
            "Uid=root" +
            "Pwd=;";

        public int Id { get; set; }
        public string Title { get; set; }
        public bool IsCompleted { get; set; }

        public bool Register()
        {
            var con = new MySqlConnection(db_config);
            var resp = false;

            try
            {
                con.Open();
                var query = con.CreateCommand();
                query.CommandText = "INSERT INTO tasks (title, completed) VALUES (@title, 0)";
                query.Parameters.AddWithValue("title", Title);

                if (query.ExecuteNonQuery() > 0)
                {
                    resp = true;
                }
            }
            catch (Exception ex)
            {
                resp = false;
            }
            finally
            {
                con.Close();
            }

            return resp;
        }
    }
}
