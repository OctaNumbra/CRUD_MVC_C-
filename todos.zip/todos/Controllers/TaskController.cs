﻿using Microsoft.AspNetCore.Mvc;

namespace todos.Controllers
{
    public class TaskController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
